import { ApparelItem } from '../types';

export const apparel: ApparelItem[] = [
  {
    id: 'ap1',
    name: 'Art Gallery T-Shirt',
    description: 'Premium cotton t-shirt featuring exclusive artwork',
    price: 35,
    imageUrl: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab',
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: 'ap2',
    name: 'Artist Edition Hoodie',
    description: 'Limited edition hoodie with gallery artwork print',
    price: 65,
    imageUrl: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7',
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: 'ap3',
    name: 'Gallery Canvas Tote',
    description: 'Eco-friendly canvas tote with artistic print',
    price: 28,
    imageUrl: 'https://images.unsplash.com/photo-1544816155-12df9643f363',
    sizes: ['One Size']
  }
];