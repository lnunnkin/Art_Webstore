import { artworks } from './artworks';
import { auctionLots } from './auctions';
import { privateSales } from './privateSales';

export const tabs = [
  { id: 'all', label: 'All Artworks' },
  { id: 'best-sellers', label: 'Best Sellers' },
  { id: 'new-arrivals', label: 'New Arrivals' },
  { id: 'auctions', label: 'Auctions' },
  { id: 'private-sales', label: 'Private Sales' }
];

export const getBestSellers = () => {
  return artworks.filter(artwork => 
    ['1', '3', '6'].includes(artwork.id)
  );
};

export const getNewArrivals = () => {
  return artworks.filter(artwork => 
    ['4', '5', '2'].includes(artwork.id)
  );
};

export const getAuctions = () => auctionLots;
export const getPrivateSales = () => privateSales;