import { Artwork } from '../types';

export const artworks: Artwork[] = [
  {
    id: '1',
    title: 'Digital Market Analysis',
    artist: 'CryptoArtist',
    price: 0.5,
    imageUrl: 'https://github.com/user-attachments/assets/c6a76d63-6612-4b6a-a2a4-d38293a851c8',
    description: 'A unique blend of traditional financial charts with contemporary digital art elements, featuring Dell stock performance overlaid with symbolic imagery.',
    dimensions: 'Digital',
    medium: 'Digital Art',
    type: 'NFT',
    editions: {
      giclee: { current: 1, total: 50 }
    },
    tokenId: '1',
    contractAddress: '0x1234567890abcdef'
  },
  {
    id: '2',
    title: 'Affinity',
    artist: 'Lunden',
    price: 0.8,
    imageUrl: 'https://github.com/user-attachments/assets/d727ffad-e77a-473b-a717-637c3b2923dd',
    description: 'A contemplative piece exploring the relationship between artist and canvas, rendered in soft, warm tones.',
    dimensions: 'Digital',
    medium: 'Digital Art',
    type: 'digital',
    editions: {
      giclee: { current: 1, total: 50 }
    },
    tokenId: '3',
    contractAddress: '0x1234567890abcdef'
  },
  {
    id: '3',
    title: 'Money Meditation',
    artist: 'Lunden',
    price: 0.75,
    imageUrl: 'https://github.com/user-attachments/assets/a1e6cd1f-998e-4e0e-a07d-e2b4b0d66686',
    description: 'A powerful digital artwork featuring the Black Pope figure overlaid on financial market data, symbolizing the intersection of traditional institutions and modern digital finance.',
    dimensions: 'Digital',
    medium: 'Digital Art / NFT',
    type: 'digital',
    editions: {
      giclee: { current: 1, total: 50 }
    },
    tokenId: '2',
    contractAddress: '0x1234567890abcdef'
  },
  {
    id: '4',
    title: 'Untitled Artwork 6',
    artist: 'Lunden',
    price: 80,
    gicleePrice: 40,
    imageUrl: 'https://github.com/user-attachments/assets/d80fc8b8-8283-430d-9e15-2c23ac374a34',
    description: 'A striking abstract composition exploring themes of structure and chaos through geometric forms and dynamic lines.',
    dimensions: '18" × 24"',
    medium: 'Fine Art Print',
    type: 'physical',
    editions: {
      original: { current: 1, total: 1 },
      giclee: { current: 1, total: 25 }
    }
  },
  {
    id: '5',
    title: 'Untitled Artwork 27',
    artist: 'Lunden',
    price: 80,
    gicleePrice: 40,
    imageUrl: 'https://github.com/user-attachments/assets/9af97c4f-7ee5-44a9-8bfb-9c3d3efa4be2',
    description: 'A mesmerizing piece that combines organic forms with mathematical precision, creating a harmonious balance between nature and technology.',
    dimensions: '18" × 24"',
    medium: 'Fine Art Print',
    type: 'physical',
    editions: {
      original: { current: 1, total: 1 },
      giclee: { current: 1, total: 25 }
    }
  },
  {
    id: '6',
    title: 'Untitled Artwork 8',
    artist: 'Lunden',
    price: 120,
    gicleePrice: 60,
    imageUrl: 'https://github.com/user-attachments/assets/23f80ba9-2b52-4013-a610-960836ee49ef',
    description: 'An intricate exploration of pattern and form, where geometric shapes create a dynamic interplay of light and shadow. This large-format piece commands attention and creates a striking focal point in any space.',
    dimensions: '36" × 48"',
    medium: 'Fine Art Print',
    type: 'physical',
    editions: {
      original: { current: 1, total: 1 },
      giclee: { current: 1, total: 25 }
    }
  },
  {
    id: '7',
    title: 'Untitled Artwork 9',
    artist: 'Lunden',
    price: 120,
    gicleePrice: 60,
    imageUrl: 'https://github.com/user-attachments/assets/2b1e8704-a345-4f2c-93a3-4ee3c79d4a29',
    description: 'A bold composition that challenges traditional perspectives through its unique arrangement of abstract elements and subtle color variations. The large format allows the intricate details to be fully appreciated.',
    dimensions: '36" × 48"',
    medium: 'Fine Art Print',
    type: 'physical',
    editions: {
      original: { current: 1, total: 1 },
      giclee: { current: 1, total: 25 }
    }
  },
  {
    id: '8',
    title: 'Digital Dreamscape',
    artist: 'Lunden',
    price: 0.65,
    imageUrl: 'https://i.imgur.com/pJwtd12.jpg',
    description: 'A surreal digital composition that blends organic forms with technological elements, creating a dreamlike landscape that bridges the natural and digital worlds.',
    dimensions: 'Digital',
    medium: 'Digital Art',
    type: 'digital',
    editions: {
      original: { current: 1, total: 1 }
    },
    tokenId: '4',
    contractAddress: '0x1234567890abcdef'
  },
  {
    id: '9',
    title: 'Cyber Synthesis',
    artist: 'Lunden',
    price: 0.7,
    imageUrl: 'https://i.imgur.com/WimbvZF.jpg',
    description: 'An exploration of digital consciousness, where abstract forms merge with cybernetic patterns to create a harmonious synthesis of mind and machine.',
    dimensions: 'Digital',
    medium: 'Digital Art',
    type: 'digital',
    editions: {
      original: { current: 1, total: 1 }
    },
    tokenId: '5',
    contractAddress: '0x1234567890abcdef'
  }
];