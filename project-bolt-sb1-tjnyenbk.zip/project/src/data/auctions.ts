import { AuctionLot } from '../types';

export const auctions: AuctionLot[] = [
  {
    id: 'a1',
    title: 'Midnight Garden',
    artist: 'Victoria Blake',
    estimatedPrice: {
      low: 8000,
      high: 12000
    },
    currentBid: 8500,
    status: 'active',
    auctionEndDate: '2024-04-15T20:00:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1585657272997-1b44c82f06f7',
    description: 'A mesmerizing nocturnal garden scene with bioluminescent elements.',
    dimensions: '60" × 48"',
    medium: 'Oil on Canvas',
    type: 'original',
    price: 8500,
    editions: {
      original: { current: 1, total: 1 }
    }
  },
  {
    id: 'a2',
    title: 'Desert Mirage',
    artist: 'Omar Hassan',
    estimatedPrice: {
      low: 15000,
      high: 20000
    },
    status: 'upcoming',
    auctionEndDate: '2024-04-20T20:00:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1577083552431-6e5fd01988f7',
    description: 'Stunning desert landscape capturing the ethereal quality of a mirage.',
    dimensions: '72" × 48"',
    medium: 'Oil on Canvas',
    type: 'original',
    price: 15000,
    editions: {
      original: { current: 1, total: 1 }
    }
  }
];