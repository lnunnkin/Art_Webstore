import { PrivateSale } from '../types';

export const privateSales: PrivateSale[] = [
  {
    id: 'p1',
    title: 'Symphony in Gold',
    artist: 'Isabella Chen',
    price: 45000,
    status: 'active',
    inquiryOnly: true,
    imageUrl: 'https://images.unsplash.com/photo-1577083555770-849fee8c6ed9',
    description: 'Masterful abstract composition in gold leaf and oil paint.',
    dimensions: '80" × 60"',
    medium: 'Mixed Media with Gold Leaf',
    type: 'original',
    editions: {
      original: { current: 1, total: 1 }
    }
  },
  {
    id: 'p2',
    title: 'Eternal Spring',
    artist: 'Richard Martinez',
    price: 28000,
    status: 'active',
    inquiryOnly: false,
    imageUrl: 'https://images.unsplash.com/photo-1578321709315-96d0ef4edc2d',
    description: 'Vibrant celebration of spring in impressionist style.',
    dimensions: '48" × 60"',
    medium: 'Oil on Canvas',
    type: 'original',
    editions: {
      original: { current: 1, total: 1 }
    }
  }
];