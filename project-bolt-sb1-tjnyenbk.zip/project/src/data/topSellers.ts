import { artworks } from './artworks';

export const topSellers = artworks.filter(artwork => 
  ['1', '3', '6'].includes(artwork.id)
);