export const colors = {
  primary: '#D2B48C', // tan
  secondary: '#8B7355', // darker tan
  background: '#FAF9F6', // off-white
  text: '#2C1810', // dark brown
  white: '#FFFFFF'
} as const;